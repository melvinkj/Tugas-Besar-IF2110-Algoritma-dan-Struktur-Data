/* Definisi type boolean */

#ifndef _BOOLEAN_H
#define _BOOLEAN_H

#define boolean unsigned char
#define true 1
#define false 0

#endif